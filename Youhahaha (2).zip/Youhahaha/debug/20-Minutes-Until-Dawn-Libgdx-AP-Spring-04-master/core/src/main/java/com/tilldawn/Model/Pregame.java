package com.tilldawn.Model;

public class Pregame {
    private String hero;
    private int duration;
}

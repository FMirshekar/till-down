package com.tilldawn.View;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.tilldawn.Control.MainMenuController;
import com.tilldawn.Control.TalentMenuController;
import com.tilldawn.Main;
import com.tilldawn.Model.GameAssetManager;
import com.tilldawn.Model.GameSettings;
import com.tilldawn.Model.UserManager;

public class TalentGuideView implements Screen {
    private Stage stage;
    private final TalentMenuController controller;
    private final TextButton returnButton;
    private final Skin skin;
    private final Label header;
    private final Main game;
    private UserManager userManager;

    public TalentGuideView(Main game, UserManager userManager, GameSettings settings, Skin skin) {
        this.game = game;
        this.controller = new TalentMenuController(settings);
        this.skin = skin;
        this.returnButton = new TextButton("Back", skin);
        this.header = new Label("Game Guides & Abilities", skin);
        this.userManager = userManager;
    }

    @Override
    public void show() {
        // 1. استفاده از ScreenViewport برای سازگاری با تمام دستگاه‌ها
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);

        // 2. تنظیمات اصلی Table
        Table mainTable = new Table(skin);
        mainTable.setFillParent(true);
        mainTable.top().left(); // چیدمان از بالا-چپ

        // 3. محاسبه مقادیر نسبی
        float screenWidth = Gdx.graphics.getWidth();
        float screenHeight = Gdx.graphics.getHeight();
        float padding = screenHeight * 0.02f;
        float listHeight = screenHeight * 0.2f;

        mainTable.add(header).colspan(2).padTop(padding * 2).padBottom(padding).row();
//
//
//        mainTable.add(new Label("Character Guides:", skin)).padLeft(padding).left();
//        List<String> heroesList = new List<>(skin);
//        heroesList.setItems(controller.getHeroGuides());
//        heroesList.getStyle().font.getData().setScale(0.9f);
//        mainTable.add(new ScrollPane(heroesList, skin))
//            .width(screenWidth * 0.6f).height(listHeight)
//            .padRight(padding).row();

        // --- لیست کلیدهای کنترل ---
        mainTable.add(new Label("Control Shortcuts:", skin)).padLeft(padding).left();
        List<String> controlsList = new List<>(skin);
        controlsList.setItems(controller.getActiveKeys());
        controlsList.getStyle().font.getData().setScale(0.9f);
        mainTable.add(new ScrollPane(controlsList, skin))
            .width(screenWidth * 0.6f).height(listHeight)
            .padRight(padding).row();

        // --- لیست رمزها ---
        mainTable.add(new Label("Secret Codes:", skin)).padLeft(padding).left();
        List<String> secretsList = new List<>(skin);
        secretsList.setItems(controller.getCheats());
        secretsList.getStyle().font.getData().setScale(0.9f);
        mainTable.add(new ScrollPane(secretsList, skin))
            .width(screenWidth * 0.6f).height(listHeight * 0.7f) // کمی کوتاه‌تر
            .padRight(padding).row();

        // --- لیست مهارت‌ها ---
        mainTable.add(new Label("Special Skills:", skin)).padLeft(padding).left();
        List<String> skillsList = new List<>(skin);
        skillsList.setItems(controller.getAbilities());
        skillsList.getStyle().font.getData().setScale(0.9f);
        mainTable.add(new ScrollPane(skillsList, skin))
            .width(screenWidth * 0.6f).height(listHeight)
            .padRight(padding).row();

        mainTable.add().expandY();
        mainTable.row();
        mainTable.add(returnButton).colspan(2)
            .padBottom(padding * 2)
            .minWidth(screenWidth * 0.3f);

        returnButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new MainMenuView(
                    new MainMenuController(game, userManager, GameAssetManager.getInstance().getSkin()),
                    skin,
                    userManager.getCurrentUser(),
                    false
                ));
            }
        });
        stage.addActor(mainTable);
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0.1f, 0.1f, 0.1f, 1);
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
        if (stage.getViewport() instanceof ScreenViewport) {
            ((ScreenViewport) stage.getViewport()).setUnitsPerPixel(1.0f);
        }
    }

    @Override public void pause() {}

    @Override public void resume() {}

    @Override public void hide() { dispose(); }

    @Override public void dispose() { if (stage != null) stage.dispose(); }
}

package com.tilldawn.View;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.tilldawn.Control.*;
import com.tilldawn.Main;
import com.tilldawn.Model.*;
import com.tilldawn.Model.enums.WeaponType;


public class PreGameMenuView implements Screen {
    private Stage stage;
    private final Label title;
    private final SelectBox<WeaponType> weaponBox;
    private final SelectBox<Integer>    durationBox;
    private final TextButton backButton, startButton;
    private final PreGameMenuController heroCtrl;
    private final WeaponMenuController weaponCtrl;
    private final DurationMenuController durationCtrl;
    private final GameStartController startCtrl;
    private final Skin skin;
    private final Main game;
    private final UserManager userManager;
    private final GameSettings settings;

    public PreGameMenuView(Main game, GameSettings settings, Skin skin, UserManager userManager) {
        this.game        = game;
        this.skin        = skin;
        this.userManager = userManager;
        this.title       = new Label("Pre-Game Setup", skin);
        this.weaponBox   = new SelectBox<>(skin);
        this.durationBox = new SelectBox<>(skin);
        this.backButton  = new TextButton("← Back", skin);
        this.startButton = new TextButton("Start Game", skin);

        this.heroCtrl     = new PreGameMenuController(settings, userManager);
        this.weaponCtrl   = new WeaponMenuController(settings);
        this.durationCtrl = new DurationMenuController(settings);
        this.startCtrl    = new GameStartController(settings);
        this.settings = settings;
    }

    @Override
    public void show() {
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);

        weaponBox.setItems(new Array<>(WeaponType.values()));
        durationBox.setItems(new Array<>(new Integer[]{2, 5, 10, 20}));

        float boxWidth = Gdx.graphics.getWidth() * 0.7f;
        weaponBox.setWidth(boxWidth);
        durationBox.setWidth(boxWidth);

        Table table = new Table(skin);
        table.setFillParent(true);
        table.center().top().padTop(50);

        table.add(title).colspan(2).padBottom(20).row();
        table.add(new Label("Weapon:", skin)).left().pad(10);
        table.add(weaponBox).pad(10).row();
        table.add(new Label("Duration:", skin)).left().pad(10);
        table.add(durationBox).pad(10).row();
        table.add(backButton).width(150).pad(20);
        table.add(startButton).width(300).pad(20).row();

        stage.addActor(table);

        backButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                MainMenuController controller = new MainMenuController(game, userManager, skin);
                game.setScreen(new MainMenuView(controller,
                    GameAssetManager.getInstance().getSkin(),
                    userManager.getCurrentUser(),
                    false));
            }
        });

        startButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                try {

                    // 2. تنظیم سلاح (پیش‌فرض: SMG)
                    WeaponType weaponType = weaponBox.getSelected() != null ?
                        weaponBox.getSelected() : WeaponType.SMG_DUAL;
                    weaponCtrl.selectWeapon(new Weapon(weaponType));

                    // 3. تنظیم مدت زمان (پیش‌فرض: 5 دقیقه)
                    int duration = durationBox.getSelected() != null ?
                        durationBox.getSelected() : 5;
                    durationCtrl.selectDuration(duration);

                    GameController gameController = new GameController(settings);
                    game.setScreen(new GameView(
                        gameController,
                        skin,
                        settings, userManager
                    ));

                } catch (Exception e) {
                    Gdx.app.error("GameStart", "خطا در شروع بازی: " + e.getMessage());

                    MainMenuController mainMenuController = new MainMenuController(game, userManager, skin);
                    Skin skin = GameAssetManager.getInstance().getSkin();
                    game.setScreen(new MainMenuView(
                        mainMenuController,
                        skin,
                        userManager.getCurrentUser(),
                        false // hasSave
                    ));
                }
            }
        });
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0, 0, 0, 1);
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {
        dispose();
    }

    @Override
    public void dispose() {
        stage.dispose();
    }

    public TextButton getStartGameButton() {
        return startButton;
    }
}

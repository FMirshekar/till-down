package com.tilldawn.Model.enums;

public enum WeaponType {
    SMG_DUAL(24, 2f, 1, 8),
    REVOLVER(6, 1f, 1, 20),
    SHOTGUN(2, 1f, 4, 10);

    private int maxAmmo;
    private float reloadTime;
    private int fireRate;
    private  double damage;
    private double originalDamage;
    private double temporaryDamage;
    private float damageBoostTimer;
    private boolean isDamageBoosted;


    WeaponType(int maxAmmo, float reloadTime, int projectiles, int damage) {
        this.maxAmmo = maxAmmo;
        this.reloadTime = reloadTime;
        this.fireRate = projectiles;
        this.damage = damage;
        this.originalDamage = damage;
        this.temporaryDamage = damage;
        this.damageBoostTimer = 10f;
        this.isDamageBoosted = false;
    }

    public void setDamage(double amount) {
        this.damage = amount;
    }

    public int getMaxAmmo() { return maxAmmo; }
    public float getReloadTime() { return reloadTime; }
    public int getfireRate() { return fireRate; }
    public double getDamage() { return damage; }

    public void applyDamagerAbility() {
            this.temporaryDamage = originalDamage * 1.25;
            this.damage = temporaryDamage;
            this.isDamageBoosted = true;
    }

    public void applyAmocreaseAbility() {
        this.maxAmmo += 5;
    }
}

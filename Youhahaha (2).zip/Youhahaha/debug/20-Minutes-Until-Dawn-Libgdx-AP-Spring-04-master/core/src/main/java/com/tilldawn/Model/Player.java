package com.tilldawn.Model;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.tilldawn.Main;
import com.tilldawn.Model.enums.Abilities;
import com.tilldawn.Model.enums.CharacterType;
import com.tilldawn.View.GameView;

import java.util.HashSet;
import java.util.Set;

public class Player {
    private Animation<TextureRegion> currentAnimation;
    private Animation<TextureRegion> idleAnimation;
    private Animation<TextureRegion> runAnimation;
    private float stateTime = 0;
    private Texture playerTexture;
    private Sprite playerSprite;
    private CollisionRect rect;
    private float time = 0;
    private final double speed;
    private Vector2 position = new Vector2();
    private Vector2 velocity = new Vector2();
    private boolean isPlayerIdle = true;
    private boolean isPlayerRunning = false;
    private boolean isAlive;
    private int hp;
    private int exp;
    private final PlayerAbilities playerAbilities;
    private final CharacterType characterType;
    private Set<Abilities> abilities = new HashSet<>();
    private int level;

    public Player(CharacterType characterType) {
        this.idleAnimation = GameAssetManager.getInstance().getCharacterIdleAnim(characterType.getIndex());
        this.runAnimation = GameAssetManager.getInstance().getCharacterRunAnim(characterType.getIndex());
        this.currentAnimation = idleAnimation;

        // استفاده از اولین فریم انیمیشن idle برای Sprite
        TextureRegion firstFrame = idleAnimation.getKeyFrame(0);
        this.playerSprite = new Sprite(firstFrame);

        position.set(Gdx.graphics.getWidth() / 2f, Gdx.graphics.getHeight() / 2f);
        playerSprite.setPosition(position.x, position.y);
        playerSprite.setSize(firstFrame.getRegionWidth() * 3, firstFrame.getRegionHeight() * 3); // تغییر به getRegionWidth/Height
        rect = new CollisionRect(position.x, position.y, playerSprite.getWidth(), playerSprite.getHeight());
        this.isAlive = true;
        this.exp = 0;
        this.playerAbilities = new PlayerAbilities();

        this.characterType = characterType;
        this.hp = characterType.getHp();
        this.speed = characterType.getSpeed();
        this.level = 0;
    }

    public void takeDamage(int damage) {
        hp -= damage;

        if (hp <= 0) {
            this.isAlive = false;
        }
    }

    public PlayerAbilities getPlayerAbilities() {
        return playerAbilities;
    }

    public void update(float deltaTime) {
        stateTime += deltaTime;
        handleInput();
        position.add(velocity.x * deltaTime, velocity.y * deltaTime);
        if(isPlayerRunning) {
            currentAnimation = runAnimation;
        } else {
            currentAnimation = idleAnimation;
        }

        playerSprite.setRegion(currentAnimation.getKeyFrame(stateTime, true));
        position.add(velocity.x * deltaTime, velocity.y * deltaTime);
        playerSprite.setPosition(position.x, position.y);
        rect.move(position.x, position.y);

        Gdx.app.log("PLAYER_UPDATE",
            String.format("Pos: (%.1f,%.1f) | Vel: (%.1f,%.1f)",
                position.x, position.y, velocity.x, velocity.y));
    }


    public void handleInput() {
        velocity.set(0, 0);

        if (Gdx.input.isKeyPressed(Input.Keys.W)) velocity.y = 1;
        if (Gdx.input.isKeyPressed(Input.Keys.S)) velocity.y = -1;
        if (Gdx.input.isKeyPressed(Input.Keys.A)) velocity.x = -1;
        if (Gdx.input.isKeyPressed(Input.Keys.D)) velocity.x = 1;

        if (!velocity.isZero()) {
            velocity.nor().scl((int)speed);
            isPlayerIdle = false;
            isPlayerRunning = true;
        } else {
            isPlayerIdle = true;
            isPlayerRunning = false;
        }
    }

    public void setPosX(float x) {
        position.x = x;
    }

    public void setPosY(float y) {
        position.y = y;
    }

    public Texture getPlayerTexture() {
        return playerTexture;
    }

    public Sprite getPlayerSprite() {
        return playerSprite;
    }

    public CollisionRect getBounds() {
        return rect;
    }

    public boolean isPlayerIdle() {
        return isPlayerIdle;
    }

    public boolean isPlayerRunning() {
        return isPlayerRunning;
    }

    public float getTime() {
        return time;
    }

    public void setTime(float time) {
        this.time = time;
    }

    public float getX() {
        return position.x;
    }

    public float getY() {
        return position.y;
    }

    public void render() {
        playerSprite.draw(Main.getBatch());

    }

    public boolean isAlive() {
        return isAlive;
    }

    public void increaseExp(int amount) {
        this.exp += amount;
        int newLevel = level;
        for (int i = 1; i < 10;i++) {
            if (exp >= 20 * i) {
                level = i + 1;
            }
        }

        if (level != newLevel) {
            GameView.showAbilitySelectionMenu();
        }
    }

    public void selectAbility(Abilities ability) {
        addAbilityIfNotExists(ability);
        handleActivateAbility(ability);
    }

    public void handleActivateAbility(Abilities ability) {
        switch (ability) {
            //TODO
        }
    }

    public int getExp() {
        return exp;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int amount) {
        this.hp = amount;
    }

    public void applySpeedyAbility() {

    }

    public boolean addAbilityIfNotExists(Abilities ability) {
        if (ability != null && !abilities.contains(ability)) {
            abilities.add(ability);
            return true;
        }
        return false;
    }

    public boolean hasAbility(Abilities ability) {
        if (abilities.contains(abilities)) {
            return true;
        }

        return false;
    }

    public int getPlayerIndex() {
        return characterType.getIndex();
    }
}

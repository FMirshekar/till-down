package com.tilldawn.Model;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.tilldawn.Model.enums.WeaponType;

public class Weapon {
    private Sprite sprite;
    private int ammo;
    private float reloadCooldown = 0;
    private final WeaponType type;
    private Player player;
    private int projectile;
    private float damageBoostTimer = 10f;
    private boolean isDamageBoosted = false;
    private double originalDamage;

    public Weapon(WeaponType type) {
        this.sprite = new Sprite(GameAssetManager.getInstance().getTexture());
        this.type = type;
        this.ammo = type.getMaxAmmo();
        this.projectile = type.getfireRate();
        this.originalDamage = type.getDamage();

        sprite.setSize(50, 50);
    }

    private int getProjectile() {
        return projectile;
    }

    public void applyProcreaseAbility() {
        projectile++;
    }

    public void update() {
        if (reloadCooldown > 0) {
            reloadCooldown -= Gdx.graphics.getDeltaTime();
        }

        if (isDamageBoosted) {
            damageBoostTimer -= Gdx.graphics.getDeltaTime();
            if (damageBoostTimer <= 0) {
                type.setDamage(originalDamage);
                isDamageBoosted = false;
            }
        }

        sprite.setX(player.getX() + 20);
        sprite.setY(player.getY() - 10);
    }

    public boolean canShoot() {
        return ammo > 0 && reloadCooldown <= 0;
    }

    public void shoot() {
        ammo--;
        if (ammo == 0) {
            reloadCooldown = type.getReloadTime();
            ammo = type.getMaxAmmo();
        }
    }


    public double getDamage() {
        return type.getDamage();
    }

    public void update(float deltaTime) {
//        if (isDamageBoosted) {
//            damageBoostTimer -= deltaTime;
//
//            if (damageBoostTimer <= 0) {
//                // برگشت به دمیج اصلی پس از اتمام زمان
//                this.damage = originalDamage;
//                this.isDamageBoosted = false;
//            }
//        }
    }

    public Sprite getSprite() {
        return sprite;
    }

    public void setPlayer(Player player) {
        this.player = player;
    }

    public WeaponType getType() {
        return type;
    }
    public int getMaxAmmo(){
        return type.getMaxAmmo();
    }

    public int getProjectileCount() {
        return type.getfireRate();
    }

    public int getCurrentAmmo() {
        return ammo;
    }

    public void setCurrentAmmo(int newAmmo) {
        this.ammo = Math.min(newAmmo, type.getMaxAmmo());
    }

}

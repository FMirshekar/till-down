package com.tilldawn.Model.enums;

public enum Abilities {
    VITALITY(-1, "Vitality"),
    PROCREASE(-1, "Procrease"),
    AMOCREASE(-1, "Amocrease"),
    DAMAGER(10f, "Damager"),
    SPEEDY(10f, "Speedy");
    private String name;
    private float duration;

    Abilities(float duration, String name) {
        this.duration = duration;
        this.name = name;
    }

    public String getName() {
        return name;
    }
}

package com.tilldawn.Model;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.tilldawn.Control.GameController;

public class InGameMenu {
    private Stage stage;
    private Table menuTable;
    private boolean isMenuVisible = false;
    private GameController controller; // اضافه کردن فیلد controller

    // تغییر constructor برای دریافت controller
    public InGameMenu(Skin skin, GameController controller) {
        this.controller = controller; // مقداردهی controller

        stage = new Stage(new ScreenViewport());
        menuTable = new Table();

        // تنظیم پس‌زمینه
        if (skin.has("default-round", Drawable.class)) {
            menuTable.setBackground(skin.getDrawable("default-round"));
        } else {
            menuTable.setBackground(skin.newDrawable("white", Color.GRAY));
        }

        menuTable.defaults().pad(20f);

        // ساخت دکمه‌ها
        TextButton pauseBtn = new TextButton("Pause", skin);
        TextButton resumeBtn = new TextButton("Resume", skin);
        TextButton abilityBtn = new TextButton("Ability", skin);
        TextButton giveUpBtn = new TextButton("Give Up", skin);
        TextButton settingsBtn = new TextButton("Settings", skin);
        TextButton exitBtn = new TextButton("Exit", skin);

        // اضافه کردن listenerها
        pauseBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                controller.setPaused(true);
                isMenuVisible = true;
                toggleMenu(); // نمایش منو هنگام مکث
            }
        });

        resumeBtn.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                controller.setPaused(false);
                toggleMenu(); // مخفی کردن منو هنگام ادامه
            }
        });

        // چیدمان منو
        menuTable.add(pauseBtn).width(150f).pad(5f).row();
        menuTable.add(resumeBtn).width(150f).pad(5f).row();
        menuTable.add(abilityBtn).width(150f).pad(5f).row();
        menuTable.add(giveUpBtn).width(150f).pad(5f).row();
        menuTable.add(settingsBtn).width(150f).pad(5f).row();
        menuTable.add(exitBtn).width(150f).pad(5f);

        menuTable.pack();
        menuTable.setPosition(
            Gdx.graphics.getWidth() - menuTable.getWidth() - 20f,
            Gdx.graphics.getHeight() - menuTable.getHeight() - 20f
        );

        stage.addActor(menuTable);
    }

    public void toggleMenu() {
        isMenuVisible = !isMenuVisible;
    }

    public void render() {
        if(isMenuVisible) {
            stage.act(Gdx.graphics.getDeltaTime());
            stage.draw();
        }
    }

    public Stage getStage() {
        return stage;
    }

    public boolean isMenuVisible() {
        return isMenuVisible;
    }

    public Table getMenuTable() {
        return menuTable;
    }
}

package com.tilldawn.Control;

import com.tilldawn.Model.GameSettings;
import com.tilldawn.Model.Weapon;

public class WeaponMenuController {
    private final GameSettings settings;

    public WeaponMenuController(GameSettings settings) {
        this.settings = settings;
    }

//      وقتی کاربر در منوی «انتخاب سلاح» یک Weapon را انتخاب می‌کند.

    public void selectWeapon(Weapon weapon) {
        settings.setSelectedWeapon(weapon);
    }

//     * برای دسترسی View به شیء GameSettings

    public GameSettings getSettings() {
        return settings;
    }
}

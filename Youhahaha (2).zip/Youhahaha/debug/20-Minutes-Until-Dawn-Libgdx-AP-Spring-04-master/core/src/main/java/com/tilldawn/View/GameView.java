package com.tilldawn.View;

import com.badlogic.gdx.*;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.tilldawn.Control.GameController;
import com.tilldawn.Main;
import com.tilldawn.Model.*;
import com.tilldawn.Model.enums.Abilities;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class GameView implements Screen, InputProcessor {
    private static Stage stage;
    private static GameController controller;
    private OrthographicCamera gameCamera;
    private Viewport gameViewport;
    private final GameSettings settings;
    private final UserManager userManager;
    private InGameMenu inGameMenu;


    public GameView(GameController controller, Skin skin, GameSettings settings, UserManager userManager) {
        gameCamera = new OrthographicCamera();
        gameViewport = new FitViewport(2000, 1000, gameCamera);
        this.controller = controller;
        this.settings = settings;
        this.userManager = userManager;
        controller.setView(this, settings);
    }

    public OrthographicCamera getGameCamera() {
        return this.gameCamera;
    }

    @Override
    public void show() {
        stage = new Stage(new ScreenViewport()); // این خط باید اول باشد
        inGameMenu = new InGameMenu(GameAssetManager.getInstance().getSkin(), controller);
        Gdx.input.setInputProcessor(inGameMenu.getStage());
        Gdx.input.setInputProcessor(this);

        InputMultiplexer multiplexer = new InputMultiplexer();
        multiplexer.addProcessor(stage);
        multiplexer.addProcessor(this);
        Gdx.input.setInputProcessor(multiplexer);
        stage.addActor(inGameMenu.getMenuTable());

        if (controller != null && controller.getPlayerController() != null) {
            gameCamera.position.set(
                controller.getPlayerController().getPlayer().getX(),
                controller.getPlayerController().getPlayer().getY(),
                0
            );
        } else {
            gameCamera.position.set(gameViewport.getWorldWidth()/2, gameViewport.getWorldHeight()/2, 0);
        }
        gameCamera.update();
    }
    @Override
    public void render(float delta) {
        // به‌روزرسانی موقعیت دوربین قبل از رندر
        if (controller != null && controller.getPlayerController() != null && !controller.isPaused()) {
            gameCamera.position.set(
                controller.getPlayerController().getPlayer().getX(),
                controller.getPlayerController().getPlayer().getY(),
                0
            );
        }
        gameCamera.update();

        // 1. به‌روزرسانی بازی فقط اگر مکث نشده باشد
        if (!controller.isPaused()) {
            if (controller != null) {
                controller.updateGame(delta);
            }
        }

        // 2. رندر بازی (همیشه)
        ScreenUtils.clear(0, 0, 0, 1);
        Main.getBatch().setProjectionMatrix(gameCamera.combined);
        controller.renderGame();

        // 3. رندر UI
        stage.getViewport().apply();
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        gameViewport.update(width, height);
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void pause() {
        try {
            if (userManager != null && userManager.getCurrentUser() != null
                && controller != null) {
                String username = userManager.getCurrentUser().getUsername();
                String saveData = controller.getCurrentGameState();
                SaveManager.saveGame(username, saveData);
                Gdx.app.log("GameSave", "Game saved successfully for user: " + username);
            }
        } catch (Exception e) {
            Gdx.app.error("GameSave", "Failed to save game", e);
        }
    }

    @Override
    public void dispose() {
    }

    @Override
    public boolean keyDown(int keycode) {
        return false;
    }

    @Override
    public boolean keyUp(int keycode) {
        return false;
    }

    @Override
    public boolean keyTyped(char character) {
        return false;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        controller.getWeaponController().handleWeaponShoot(screenX, screenY);
        return false;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchCancelled(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        return false;
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        controller.getWeaponController().handleWeaponRotation(screenX, screenY);
        return false;
    }

    @Override
    public boolean scrolled(float amountX, float amountY) {
        return false;
    }

    public static void showAbilitySelectionMenu() {
        List<Abilities> randomAbilities = getRandomAbilities(3);
        showAbilityMenu(randomAbilities);
    }

    private static List<Abilities> getRandomAbilities(int count) {
        ArrayList<Abilities> allAbilities = new ArrayList<>(Arrays.asList(Abilities.values()));
        ArrayList<Abilities> availableAbilities = new ArrayList<>();

        for (Abilities ability : allAbilities) {
            if (!controller.getPlayerController().getPlayer().hasAbility(ability)) {
                availableAbilities.add(ability);
            }
        }

        count = Math.min(count, availableAbilities.size());
        List<Abilities> result = new ArrayList<>();
        Random random = new Random();

        for (int i = 0; i < count; i++) {
            int randomIndex = random.nextInt(availableAbilities.size());
            result.add(availableAbilities.remove(randomIndex));
        }

        return result;
    }

    private static void showAbilityMenu(List<Abilities> abilities) {
        Stage abilityStage = new Stage(new ScreenViewport());
        Table table = new Table();
        table.setFillParent(true);
        abilityStage.addActor(table);

        Skin skin = GameAssetManager.getInstance().getSkin();

        for (Abilities ability : abilities) {
            TextButton abilityButton = new TextButton(ability.name(), skin);

            abilityButton.addListener(new ClickListener() {
                @Override
                public void clicked(InputEvent event, float x, float y) {
                    controller.getPlayerController().getPlayer().selectAbility(ability);
                    abilityStage.dispose();
                    Gdx.input.setInputProcessor(stage);
                }
            });

            table.add(abilityButton).pad(10).row();
        }

        Gdx.input.setInputProcessor(abilityStage);
    }
}

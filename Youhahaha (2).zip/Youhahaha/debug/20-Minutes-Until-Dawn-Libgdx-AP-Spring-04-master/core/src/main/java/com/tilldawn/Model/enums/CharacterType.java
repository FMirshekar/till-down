package com.tilldawn.Model.enums;

public enum CharacterType {
    SHANA(0, 4, 400f, "Shana"),
    DIAMOND(1, 7, 100f, "Diamond"),
    SCARLET(2, 3, 500f, "Scarlet"),
    LILITH(3, 5, 300f, "Lilith"),
    DASHER(4, 2, 10, "Dasher");

    private int index;
    private int hp;
    private float speed;
    private String name;

    CharacterType(int index, int hp, float speed, String name) {
        this.index = index;
        this.hp = hp;
        this.speed = speed;
        this.name = name;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public double getSpeed() {
        return speed;
    }

    public int getIndex() {
        return index;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static CharacterType getCharacterByIndex(int index) {
        switch (index) {
            case 0:
                return SHANA;
            case 1:
                return DIAMOND;
            case 2:
                return SCARLET;
            case 3:
                return LILITH;
            case 4:
                return DASHER;
        }
        return SHANA;
    }
}

package com.tilldawn.Control;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Dialog;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.tilldawn.Main;
import com.tilldawn.Model.*;
import com.tilldawn.View.*;

public class MainMenuController {
    private MainMenuView view;
    private final Main game;
    private final UserManager userManager;
    private final GameSettings settings;
    private final Skin skin;

    public MainMenuController(Main game, UserManager userManager, Skin skin) {
        this.game = game;
        this.userManager = userManager;
        this.settings = new GameSettings();
        this.skin = skin;
    }

    public void showDialog(String message) {
        if (view != null) {
            try {
                view.showDialog(message);
            } catch (Exception e) {
                Gdx.app.error("Dialog", "Error showing dialog", e);
            }
        }
    }

    private boolean hasSavedGame() {
        return SaveManager.doesUserHaveSave(userManager.getCurrentUser().getUsername());
    }

    public void setView(MainMenuView view) {
        this.view = view;
    }

    public void handleLogout() {
        userManager.logout();

        game.setScreen(new LoginScreen(game, userManager));
        MusicManager.getInstance().stopMusic();
    }

    public void handleMainMenuButtons() {
        view.getSettingsButton().addListener(new ClickListener() {
            public void clicked(InputEvent e, float x, float y) {
                SettingsManager settings = SettingsManager.getInstance();;
                game.setScreen(new SettingsScreen(game, userManager, settings));
            }
        });
        view.getProfileButton().addListener(new ClickListener() {
            public void clicked(InputEvent e, float x, float y) {
                game.setScreen(new ProfileScreen(game, userManager));
            }
        });
        view.getPregameButton().addListener(new ClickListener() {
            public void clicked(InputEvent e, float x, float y) {
                game.setScreen(new PreGameMenuView(game,
                    settings,
                    GameAssetManager.getInstance().getSkin(),userManager));
            }
        });
        view.getScoreboardButton().addListener(new ClickListener() {
            public void clicked(InputEvent e, float x, float y) {
                game.setScreen(new ScoreboardView(
                    GameAssetManager.getInstance().getSkin(),
                    userManager
                ));
            }
        });
        view.getTalentButton().addListener(new ClickListener() {
            public void clicked(InputEvent e, float x, float y) {
                game.setScreen(new TalentGuideView(
                    game,
                    userManager,
                    settings,
                    GameAssetManager.getInstance().getSkin()
                ));
            }
        });
        view.getContinueButton().addListener(new ClickListener() {
            public void clicked(InputEvent e, float x, float y) {
                if (hasSavedGame()) {
                    loadSavedGame(view);
                } else {
                    showDialog("No saved game found!");
                }
            }
        });
        view.getLogoutButton().addListener(new ClickListener() {
            public void clicked(InputEvent e, float x, float y) {
                userManager.logout();
//            game.setScreen(new LoginScreen(game, userManager));
            }
        });
        view.getExitButton().addListener(new ClickListener() {
            public void clicked(InputEvent e, float x, float y) {
                Gdx.app.exit();
            }
        });
    }

    private void showErrorDialog(String message, MainMenuView view) {
        Stage dialogStage = view.getStage();

        if (dialogStage == null) {
            Gdx.app.error("Dialog", "Stage is not available");
            return;
        }

        Dialog dialog = new Dialog("Error", skin);
        dialog.text(message);
        dialog.button("OK");
        dialog.show(dialogStage);
    }

    private void loadSavedGame(MainMenuView view) {
        try {
            String username = userManager.getCurrentUser().getUsername();
            String savedData = SaveManager.loadGame(username);

            if (savedData == null || savedData.isEmpty()) {
                showErrorDialog("No saved game found", view);
                return;
            }

            GameController gameController = new GameController(settings);

            gameController.loadGameState(savedData);

            GameView gameView = new GameView(gameController,
                GameAssetManager.getInstance().getSkin(),
                settings, userManager);
            game.setScreen(gameView);

        } catch (Exception e) {
            showErrorDialog("Failed to load game", view);
            Gdx.app.error("LoadGame", "Error loading game", e);
        }
    }

    public UserManager getUserManager() {
        return userManager;
    }

}

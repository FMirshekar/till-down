package com.tilldawn.Model;

public class PlayerAbilities {
    public boolean hasVitality;
    public boolean hasDamager;
    public boolean hasPrecrease;
    public boolean hasAmocrease;
    public boolean hasSpeedy;
    private String vitalityName = "vitality";
    private String damagerName = "damager";
    private String procreaseName = "procrease";
    private String amocreaseName = "amocrease";
    private String speedyName = "speedy";

    public PlayerAbilities() {
        this.hasAmocrease = false;
        this.hasDamager = false;
        this.hasPrecrease = false;
        this.hasSpeedy = false;
        this.hasVitality = false;
    }

    public void setHasVitality(boolean hasVitality) {
        this.hasVitality = hasVitality;
    }

    public void setHasDamager(boolean hasDamager) {
        this.hasDamager = hasDamager;
    }

    public void setHasSpeedy(boolean hasSpeedy) {
        this.hasSpeedy = hasSpeedy;
    }

    public void setHasAmocrease(boolean hasAmocrease) {
        this.hasAmocrease = hasAmocrease;
    }

    public void setHasPrecrease(boolean hasPrecrease) {
        this.hasPrecrease = hasPrecrease;
    }

    public void applyVitality(Player player) {
       player.setHp(player.getHp() + 1);
    }

    public void setDamager() {

    }

    public void precrease() {

    }

    public void amocrease() {

    }

    public void speedy() {

    }

    public String getAmocreaseName() {
        return amocreaseName;
    }

    public String getDamagerName() {
        return damagerName;
    }

    public String getProcreaseName() {
        return procreaseName;
    }

    public String getSpeedyName() {
        return speedyName;
    }

    public String getVitalityName() {
        return vitalityName;
    }
}

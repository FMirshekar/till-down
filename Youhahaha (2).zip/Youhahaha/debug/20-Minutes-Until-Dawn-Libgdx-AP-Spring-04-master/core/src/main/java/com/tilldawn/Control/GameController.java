package com.tilldawn.Control;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.utils.Json;
import com.tilldawn.Main;
import com.tilldawn.Model.*;
import com.tilldawn.Model.enums.CharacterType;
import com.tilldawn.Model.enums.WeaponType;
import com.tilldawn.View.GameView;
import java.util.Random;
import java.util.HashMap;
import java.util.Map;

public class GameController {
    private GameView view;
    private PlayerController playerController;
    private WorldController worldController;
    private WeaponController weaponController;
    private EnemyController enemyController;
    private final GameSettings settings;
    private int currentScore = 0;
    private float elapsedTime = 0f;
    private boolean isPaused = false;

    public int getCurrentScore() {
        return currentScore;
    }

    public void setCurrentScore(int score) {
        this.currentScore = score;
    }

    public float getElapsedTime() {
        return elapsedTime;
    }

    public void setElapsedTime(float time) {
        this.elapsedTime = time;
    }

    public GameController(GameSettings settings) {
        this.settings = settings;
    }

    public void setView(GameView view, GameSettings settings) {
        this.view = view;
        Random random = new Random();
        int randomIndex = random.nextInt(5);
        CharacterType randomCharacter = CharacterType.getCharacterByIndex(randomIndex);
        this.playerController = new PlayerController(new Player(randomCharacter));
        this.worldController = new WorldController(playerController, view.getGameCamera());

        Weapon chosen = settings.getSelectedWeapon();
        if (chosen == null) {
            chosen = new Weapon(WeaponType.SMG_DUAL);
        }

        this.enemyController = new EnemyController(playerController);

        this.weaponController = new WeaponController(
            chosen,
            playerController.getPlayer(),
            view.getGameCamera(),
            settings,
            enemyController
        );
    }

    public void renderGame() {

        if (!Main.getBatch().isDrawing()) {
            Main.getBatch().begin();
        }

        try {
            worldController.render();
            playerController.getPlayer().render();
            enemyController.render();
            weaponController.render();
        } finally {
            if (Main.getBatch().isDrawing()) {
                Main.getBatch().end();
            }
        }
    }

    public void updateGame(float delta) {
        if (view != null) {

            playerController.update(delta);
            weaponController.update(delta);
            enemyController.update(delta);
            worldController.update(delta);
        }
    }

    public PlayerController getPlayerController() {
        return playerController;
    }

    public WeaponController getWeaponController() {
        return weaponController;
    }

    public void loadGameState(String savedData) {
        try {
            Json json = new Json();
            Map<String, Object> data = json.fromJson(HashMap.class, savedData);

            this.currentScore = ((Double) data.getOrDefault("score", 0)).intValue();
            this.elapsedTime = ((Double) data.getOrDefault("time", 0f)).floatValue();

            if (playerController != null && playerController.getPlayer() != null) {
                float x = ((Double) data.getOrDefault("playerX", 0f)).floatValue();
                float y = ((Double) data.getOrDefault("playerY", 0f)).floatValue();
                playerController.getPlayer().setPosX(x);
                playerController.getPlayer().setPosY(y);
            }

        } catch (Exception e) {
            Gdx.app.error("LoadGame", "Error loading game state", e);
        }
    }

    public String getCurrentGameState() {
        Json json = new Json();
        Map<String, Object> saveData = new HashMap<>();

        saveData.put("score", currentScore);
        saveData.put("time", elapsedTime);

        if (playerController != null && playerController.getPlayer() != null) {
            saveData.put("playerX", playerController.getPlayer().getX());
            saveData.put("playerY", playerController.getPlayer().getY());
        }

        return json.toJson(saveData);
    }

    public void setPaused(boolean paused) {
        this.isPaused = paused;
    }

    public boolean isPaused() {
        return isPaused;
    }

}

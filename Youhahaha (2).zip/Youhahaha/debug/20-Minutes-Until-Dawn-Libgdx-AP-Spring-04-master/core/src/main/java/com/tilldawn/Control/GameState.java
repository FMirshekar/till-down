package com.tilldawn.Control;

import com.badlogic.gdx.utils.Json;

public class GameState {
    private int level;
    private int score;

    public String toJson() {
        Json json = new Json();
        return json.toJson(this);
    }

    public static GameState fromJson(String json) {
        Json j = new Json();
        return j.fromJson(GameState.class, json);
    }
}

package com.tilldawn.View;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.tilldawn.Control.MainMenuController;
import com.tilldawn.Control.RegisterController;
import com.tilldawn.Main;
import com.tilldawn.Model.GameAssetManager;
import com.tilldawn.Model.User;
import com.tilldawn.Model.UserManager;

public class SignUpScreen extends ScreenAdapter {
    private Main game;
    private UserManager userManager;
    private Stage stage;
    private Skin skin;
    private Texture backgroundTexture;
    private RegisterController registerController;

    private TextField usernameField;
    private TextField passwordField;
    private SelectBox<String> securityQuestionBox;
    private TextField securityAnswerField;
    private Label messageLabel;

    public SignUpScreen(Main game, UserManager userManager) {
        this.game = game;
        this.userManager = userManager;
        this.skin = GameAssetManager.getInstance().getSkin();
        this.registerController = new RegisterController(game, userManager, this);
    }

    @Override
    public void show() {
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);

        backgroundTexture = new Texture(Gdx.files.internal("background.jpg"));

        Table table = new Table();
        table.setFillParent(true);
        table.defaults().pad(5);
        stage.addActor(table);

        usernameField = new TextField("", skin);
        passwordField = new TextField("", skin);
        passwordField.setPasswordMode(true);
        passwordField.setPasswordCharacter('*');

        securityQuestionBox = new SelectBox<>(skin);
        securityQuestionBox.setItems("What is your favorite color?");

        securityAnswerField = new TextField("", skin);
        messageLabel = new Label("", skin);
        messageLabel.setWrap(true);

        TextButton registerButton = new TextButton("Register", skin);
        TextButton guestButton = new TextButton("Play as Guest", skin);
        TextButton backButton = new TextButton("Back", skin);

        registerButton.addListener(new ClickListener() {
            public void clicked(InputEvent event, float x, float y) {
                String username = usernameField.getText().trim();
                String password = passwordField.getText().trim();
                String question = securityQuestionBox.getSelected();
                String answer = securityAnswerField.getText().trim();

                String result = registerController.handleRegister(username, password, question, answer);
                messageLabel.setText(result);
            }
        });

        guestButton.addListener(new ClickListener() {
            public void clicked(InputEvent event, float x, float y) {
                userManager.createGuestUser();
                User currentUser = userManager.getCurrentUser();
                Skin skin = GameAssetManager.getInstance().getSkin();
                MainMenuController controller = new MainMenuController(game,
                    userManager,
                    GameAssetManager.getInstance().getSkin());
                game.setScreen(new MainMenuView(controller, skin, currentUser, false));
            }
        });

        backButton.addListener(new ClickListener() {
            public void clicked(InputEvent event, float x, float y) {
                game.setScreen(new LoginScreen(game, userManager));
            }
        });

        float inputWidth = 750;
        float inputHeight = 105;

        table.add(new Label("Username:", skin)).padBottom(10);
        table.add(usernameField).width(inputWidth).height(inputHeight).padBottom(10).row();

        table.add(new Label("Password:", skin)).padBottom(10);
        table.add(passwordField).width(inputWidth).height(inputHeight).padBottom(10).row();

        table.add(new Label("Security Question:", skin)).padBottom(10);
        table.add(securityQuestionBox).width(inputWidth).height(inputHeight).padBottom(10).row();

        table.add(new Label("Answer:", skin)).padBottom(10);
        table.add(securityAnswerField).width(inputWidth).height(inputHeight).padBottom(20).row();

        table.add(registerButton).colspan(2).width(inputWidth).height(100).padBottom(10).row();
        table.add(guestButton).colspan(2).width(inputWidth).height(100).padBottom(10).row();
        table.add(backButton).colspan(2).width(inputWidth).height(100).padBottom(10).row();
        table.add(messageLabel).colspan(2).width(inputWidth).padTop(10);
    }

    @Override
    public void render(float delta) {
        stage.getBatch().begin();
        stage.getBatch().draw(backgroundTexture, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        stage.getBatch().end();

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        stage.dispose();
        backgroundTexture.dispose();
    }
}

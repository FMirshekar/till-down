package com.tilldawn.View;

public class HintMenuView {
}

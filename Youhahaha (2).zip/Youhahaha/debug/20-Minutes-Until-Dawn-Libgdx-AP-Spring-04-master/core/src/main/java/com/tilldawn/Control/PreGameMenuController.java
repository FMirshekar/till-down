package com.tilldawn.Control;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.tilldawn.Main;
import com.tilldawn.Model.*;
import com.tilldawn.View.GameView;
import com.tilldawn.View.PreGameMenuView;

import java.awt.event.InputEvent;

public class PreGameMenuController {
    private PreGameMenuView view;
    private Pregame pregame;
    private final GameSettings settings;
    private final UserManager userManager;

    public PreGameMenuController(GameSettings settings, UserManager userManager) {
        this.settings = settings;

        settings.addKeyBinding("W");
        settings.addKeyBinding("A");
        settings.addKeyBinding("S");
        settings.addKeyBinding("D");

        settings.addCheatCode("FMRHS");
        settings.addCheatCode("MOMSH");

        settings.addAbility(new Ability("Fireball", "Shoots a fiery projectile"));
        settings.addAbility(new Ability("Dash", "Quickly moves forward"));
        this.userManager = userManager;
    }

    public GameSettings getSettings() {
        return settings;
    }


    public void setView(PreGameMenuView view) {
        this.view = view;
        this.pregame = new Pregame();
    }

    public void handlePreGameMenuButtons() {
        view.getStartGameButton().addListener(new ClickListener() {
            public void clicked(InputEvent event, float x, float y) {

                Main.getMain().getScreen().dispose();
                GameController gameController = new GameController(
                    settings
                );

                GameView gameView = new GameView(
                    gameController,
                    GameAssetManager.getInstance().getSkin(),
                    settings,
                    userManager  // ارسال UserManager به GameView
                );

                Main.getMain().setScreen(gameView);
            }
        });
    }

}

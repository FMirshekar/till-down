package com.tilldawn.Control;

import com.tilldawn.Model.GameSettings;

public class GameStartController {
    private final GameSettings settings;

    public GameStartController(GameSettings settings) {
        this.settings = settings;
    }

}

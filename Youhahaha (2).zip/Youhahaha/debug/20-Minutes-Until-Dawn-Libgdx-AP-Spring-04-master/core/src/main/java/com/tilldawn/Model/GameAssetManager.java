
package com.tilldawn.Model;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.utils.Array;

import java.util.Arrays;

public class GameAssetManager {
    private static GameAssetManager instance;
    private final Skin skin;
    private Animation<TextureRegion> eyebatFlyAnim;
    private Animation<TextureRegion> tentacleWalkAnim;
    private Animation<TextureRegion> characterIdleAnim;
    private Animation<TextureRegion> characterRunAnim;
    private Texture playerIdleTexture;
    private Texture playerRunTexture;
    private Animation<TextureRegion> playerIdleAnim;
    private Texture smgTexture;
    private Texture bulletTexture;
    private Animation<TextureRegion> treeIdleAnim;
    private Animation<TextureRegion> treeWalkAnim;
    private Texture[] treePowerupTexture = new Texture[2];

    private GameAssetManager() {
        skin = new Skin(Gdx.files.internal("skin/pixthulhu-ui.json"));
        loadTextures();
    }

    public static synchronized GameAssetManager getInstance() {
        if (instance == null) {
            instance = new GameAssetManager();
        }
        return instance;
    }

    public void loadTextures() {
        loadEyebatAnimations();
        loadTentacleAnimations();

        Array<TextureRegion> playerFrames = new Array<>();
        for (int i = 0; i < 6; i++) {
            playerFrames.add(new TextureRegion(new Texture("1/Idle_" + i + ".png")));
        }
        playerIdleAnim = new Animation<>(0.1f, playerFrames);
        smgTexture = new Texture("smg/SMGStill.png");
        bulletTexture = new Texture("bullet.png");
        loadTreeAssets();
        loadCharacterAnimations();
    }

    private void loadEyebatAnimations() {
        Array<TextureRegion> frames = new Array<>();
        for (int i = 0; i < 4; i++) {
            frames.add(new TextureRegion(new Texture("eyebat/T_EyeBat_" + i + ".png")));
        }
        eyebatFlyAnim = new Animation<>(0.1f, frames);
    }

    private void loadTentacleAnimations() {
        Array<TextureRegion> frames = new Array<>();
        for (int i = 0; i < 4; i++) {
            frames.add(new TextureRegion(new Texture("tentacle/walk_" + i + ".png")));
        }
        tentacleWalkAnim = new Animation<>(0.1f, frames);
    }

    public void loadCharacterAnimations() {
        characterIdleAnim = createAnimation(0, "Idle", 6, 0.1f); // charIndex=0 برای پلیر اصلی
        characterRunAnim = createAnimation(0, "Run", 4, 0.08f);
    }

//    public void loadCharacterAnimations() {
//        characterIdleAnim = createAnimation("1/Idle_", 6, 0.1f);
//        characterRunAnim = createAnimation("1/Run_", 4, 0.08f);
//    }

    private Animation<TextureRegion> createAnimation(int charIndex, String animType,
                                                      int frameCount, float frameDuration) {
        Array<TextureRegion> frames = new Array<>();
        for (int i = 0; i < frameCount; i++) {
            String path;
            if (animType.equals("Run")) {
                // ساختار فایل‌های Run: 1/characters/Run_X_Y.png
                path = "1/characters/" + animType + "_" + charIndex + "_" + i + ".png";
            } else {
                // ساختار فایل‌های Idle: 1/Idle_X.png
                path = "1/" + animType + "_" + i + ".png";
            }
            frames.add(new TextureRegion(new Texture(path)));
        }
        return new Animation<>(frameDuration, frames);
    }

    // متدهای دسترسی به انیمیشن‌ها
    public Animation<TextureRegion> getCharacterIdleAnim(int charIndex) {
        Array<TextureRegion> frames = new Array<>();
        for (int i = 0; i < 6; i++) {
            frames.add(new TextureRegion(new Texture("1/Idle_" + i + ".png")));
        }
        return new Animation<>(0.1f, frames);
    }

    public Animation<TextureRegion> getCharacterRunAnim(int charIndex) {
        Array<TextureRegion> frames = new Array<>();
        for (int i = 0; i < 4; i++) {
            frames.add(new TextureRegion(new Texture("1/characters/Run_" + charIndex + "_" + i + ".png")));
        }
        return new Animation<>(0.08f, frames);
    }

    public Animation<TextureRegion> getTentacleWalkAnim() {
        return new Animation<>(0.1f,
            new TextureRegion(new Texture("tentacle/walk_0.png")),
            new TextureRegion(new Texture("tentacle/walk_1.png")),
            new TextureRegion(new Texture("tentacle/walk_2.png")),
            new TextureRegion(new Texture("tentacle/walk_3.png"))
        );
    }

    private void loadTreeAssets() {
        Array<TextureRegion> treeIdleFrames = new Array<>();
        for (int i = 0; i < 3; i++) {
            treeIdleFrames.add(new TextureRegion(new Texture("TreeMonster/T_TreeMonster_" + i + ".png")));
        }
        treeIdleAnim = new Animation<>(0.15f, treeIdleFrames);

        Texture walkSheet = new Texture("TreeMonster/T_TreeMonsterWalking.png");
        TextureRegion[][] tmp = TextureRegion.split(walkSheet, walkSheet.getWidth()/4, walkSheet.getHeight());
        Array<TextureRegion> walkFrames = new Array<>();
        for (int i = 0; i < 4; i++) {
            walkFrames.add(tmp[0][i]);
        }
        treeWalkAnim = new Animation<>(0.1f, walkFrames);

        for (int i = 0; i < 2; i++) {
            treePowerupTexture[i] = new Texture("TreeMonster/T_PowerupTreeArrows_" + i + ".png");
        }
    }

    public void dispose() {
        skin.dispose();
        smgTexture.dispose();
        bulletTexture.dispose();
//        playerIdleTexture.dispose();
//        playerRunTexture.dispose();

        // اضافه کردن dispose برای بافت‌های جدید (تغییر اصلی 4)

//        for (TextureRegion region : eyebatFlyAnim.getKeyFrames()) {
//            if (region != null && region.getTexture() != null) {
//                region.getTexture().dispose();
//            }
//        }
//        for (TextureRegion region : tentacleWalkAnim.getKeyFrames()) {
//            region.getTexture().dispose();
//        }
//
//        for (Texture tex : treePowerupTexture) {
//            if (tex != null) tex.dispose();
//        }
    }

    public Texture get(String path, Class<Texture> type) {
        if (type == Texture.class) {
            return new Texture(Gdx.files.internal(path));
        }
        return null;
    }

    public Animation<TextureRegion> getEyebatFlyAnim() {
        return eyebatFlyAnim; // تغییر از ساخت جدید به بازگرداندن انیمیشن از پیش بارگذاری شده
    }

    public Texture getTexture() {
        return smgTexture;
    }

    public Skin getSkin() { return skin; }
    public Animation<TextureRegion> getTreeIdleAnim() { return treeIdleAnim; }
    public Animation<TextureRegion> getCharacterIdleAnimation() { return characterIdleAnim; }
    public Animation<TextureRegion> getCharacterRunAnimation() { return characterRunAnim; }

}

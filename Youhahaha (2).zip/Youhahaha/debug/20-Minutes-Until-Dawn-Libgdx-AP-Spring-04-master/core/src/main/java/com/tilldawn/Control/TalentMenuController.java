package com.tilldawn.Control;

import com.badlogic.gdx.utils.Array;
import com.tilldawn.Model.Ability;
import com.tilldawn.Model.GameSettings;

public class TalentMenuController {
    private final GameSettings settings;

    public TalentMenuController(GameSettings settings) {
        this.settings = settings;
    }


    public Array<String> getActiveKeys() {
        Array<String> keys = new Array<>();
        for (String key : settings.getKeyBindings()) {
            keys.add(key);
        }
        return keys;
    }


    public Array<String> getCheats() {
        Array<String> cheats = new Array<>();
        for (String code : settings.getCheatCodes()) {
            cheats.add(code + " → " + lookupCheatEffect(code));
        }
        return cheats;
    }

    private String lookupCheatEffect(String code) {
        switch (code) {
            case "IDDQD": return "God Mode";
            case "IDKFA": return "All Weapons";
            default:      return "Unknown Effect";
        }
    }

    public Array<String> getAbilities() {
        Array<String> abs = new Array<>();
        for (Ability a : settings.getAcquiredAbilities()) {
            abs.add(a.getName() + ": " + a.getEffect());
        }
        return abs;
    }
}

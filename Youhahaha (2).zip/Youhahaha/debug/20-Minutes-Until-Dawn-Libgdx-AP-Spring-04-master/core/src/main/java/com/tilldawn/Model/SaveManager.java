package com.tilldawn.Model;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;

public class SaveManager {
    private static final String SAVE_FOLDER = "saves/";
    private static final String SAVE_EXTENSION = ".save";

    public static boolean doesUserHaveSave(String username) {
        FileHandle file = Gdx.files.local(SAVE_FOLDER + username + SAVE_EXTENSION);
        return file.exists();
    }

    public static void saveGame(String username, String data) {
        FileHandle dir = Gdx.files.local(SAVE_FOLDER);
        if (!dir.exists()) dir.mkdirs();
        FileHandle file = Gdx.files.local(SAVE_FOLDER + username + SAVE_EXTENSION);
        file.writeString(data, false);
    }

    public static String loadGame(String username) {
        FileHandle file = Gdx.files.local(SAVE_FOLDER + username + SAVE_EXTENSION);
        return file.exists() ? file.readString() : null;
    }
}

package com.tilldawn.util;

public interface FileChooserInterface {
    String chooseFile();
}
